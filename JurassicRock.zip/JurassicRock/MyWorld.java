import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    private counter vidas;
    private counter level;
    
    private int velocidad_dino;
    private int score_rockero;
    private int num_adelantamiento_enemigos;
    private dino rex;
    private int num_vidas;
    private int num_enemigos;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld(){    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        
        score_rockero =0;
        num_adelantamiento_enemigos = 2;
        velocidad_dino = 2;
        
        vidas = new counter ("Vidas: ");
        level = new counter ("Nivel: ");
        level.add (1);
        rex = new dino (velocidad_dino);
        
        addObject(rex, 290, 350);
        addObject(level, 80, 40);
        addObject(vidas, 80, 70);
        
    }
    
     public void act(){
        aumentar_dificultad();
        entran_enemigos();
    }
    
    public int getRandomNumber(int start,int end){
       int normal = Greenfoot.getRandomNumber(end-start+1);
       return normal+start;
    }
    
    public void aumentar_vidas(int valor){
        vidas.add(valor);
    }
    
    /*public void aumentar_score(){
        score_rockero++;
    }*/
    
    public void disminuir_vidas(int valor){
        num_vidas--;
    }
    
    
    public void aumentar_dificultad(){
        if(score_rockero == 2){
            velocidad_dino++;
            level.add(1);
            rex.aumenta_velocidad();
        }
    }
   
    public void entran_enemigos(){
        
        if(num_enemigos == 0){
            
            int camino = getRandomNumber(0,3);
            
            if(camino == 0){
                addObject(new Estramonio(velocidad_dino),180, 80);
            }
            else if( camino == 1){
                addObject(new Megaconus (velocidad_dino),290, 80);
            }
            else {
                addObject(new Rockero(velocidad_dino),410, 80);
            } 
            camino ++;
            camino = camino % 3;
            if(camino == 0){
                addObject(new Estramonio(velocidad_dino),180, 80);
            }
            else if( camino == 1){
                addObject(new Megaconus (velocidad_dino),290, 80);
            }
            else {
                addObject(new Rockero(velocidad_dino),410, 80);
            }
            num_enemigos = 3;
            
          }
    }
    
   }
