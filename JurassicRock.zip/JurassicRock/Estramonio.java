import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Estramonio here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Estramonio extends Actor
{
    private int speed;
    
    public Estramonio (int velocidad){
        speed=velocidad;
        
    }
    /**
     * Act - do whatever the Estramonio wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        
        setLocation ( getX () ,  getY () + speed );
        if (getY () >= getWorld ().getHeight () -1){
            
            MyWorld juego = (MyWorld) getWorld ();
            juego.disminuir_vidas (1);
            juego.removeObject(this);
           
    }    
  }
}
