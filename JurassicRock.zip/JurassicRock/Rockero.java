import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Rockeros here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rockero extends Actor
{
    private int speed;
    
    public Rockero (int velocidad){
        speed=velocidad;
        
    }
    /**
     * Act - do whatever the Rockeros wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        setLocation ( getX () ,  getY () + speed );
        if (getY () >= getWorld ().getHeight () -1){
            
            MyWorld juego = (MyWorld) getWorld ();
            juego.disminuir_vidas(1);
            juego.removeObject(this);
            
        }
 
    }
    
   }    

