
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class dino here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class dino extends Actor
{
    private int speed;
    
    public dino (int velocidad){
        speed=velocidad;
        
    }
    /**
     * Act - do whatever the dino wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() {
        // Add your action code here.
        if (Greenfoot.isKeyDown ("right")){
            if (getX () < 460)
            setLocation ( getX () + speed , getY () );
          
        }   
        if (Greenfoot.isKeyDown ("left")){
            if (getX () > 140)
            setLocation ( getX () - speed , getY () );
           
    }
    
        if (Greenfoot.isKeyDown ("up")){
              if (getY () > 140)
            setLocation ( getX () , getY () -speed );
          
    }       
    
        if (Greenfoot.isKeyDown ("down")){
            setLocation ( getX () , getY () +speed );
          
    }
    Actor Rockero;
      Rockero = getOneObjectAtOffset(0,0,Rockero.class);
      if (Rockero != null){
          World mundo;
          mundo = getWorld ();
          mundo.removeObject(Rockero);
        }   
     Actor Megaconus;
      Megaconus = getOneObjectAtOffset(0,0,Megaconus.class);
      if (Megaconus != null){
          World mundo;
          mundo = getWorld ();
          mundo.removeObject(Megaconus);
       } 
     Actor Estramonio;
      Estramonio = getOneObjectAtOffset(0,0,Estramonio.class);
      if (Estramonio != null){
          World mundo;
          mundo = getWorld ();
          mundo.removeObject(Estramonio);
       } 
	 
       
}
  
 /* public void checkCollision(){
      Actor Rockero;
      Rockero = getOneObjectAtOffset(0,0,Rockero.class);
      if (Rockero != null){
          World mundo;
          mundo = getWorld ();
          mundo.removeObject(Rockero);
        }

    }*/
  public void aumenta_velocidad (){
        speed ++;
  }
}