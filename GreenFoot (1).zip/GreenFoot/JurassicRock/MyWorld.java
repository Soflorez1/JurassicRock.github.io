import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
     
    private counter score;
    private counter level;
    
    private int velocidad_rex;
    private int num_adelantamientos;
    private int num_adelantamientos_nivel;
    private rex dino;
    private int num_rivales;
    private int num_amigos;
    
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 620, 1); 
        
        num_adelantamientos = 0;
        num_adelantamientos_nivel = 4;
        velocidad_rex = 2;
        
        score = new counter("Score:   ");
        level = new counter("Level:   ");
        level.add(1);
        dino = new rex(velocidad_rex);
        
        addObject(dino, 500, 550);
        addObject(score,135, 25);
        addObject(level, 135, 60);
    }
    
    public void act(){
        aumentar_dificultad();
        anadir_rivales();
        //anadir_amigos();
    }
    
    public int getRandomNumber(int start,int end){
       int normal = Greenfoot.getRandomNumber(end-start+1);
       return normal+start;
    }
    
    public void aumentar_puntuacion(int valor){
        score.add(valor);
    }
    
    public void aumentar_num_adelantamientos(){
        num_adelantamientos++;
    }
    
    public void disminuir_num_rivales(){
        num_rivales--;
    }
    
    /*public void disminuir_num_amigos(){
        num_amigos--;
    }*/

    public void aumentar_dificultad(){
        if(num_adelantamientos == num_adelantamientos_nivel){
            num_adelantamientos = 0;
            num_adelantamientos_nivel = num_adelantamientos_nivel + 2;
            velocidad_rex++;
            level.add(1);
            dino.aumenta_velocidad();
        }
    }
    
    public void anadir_rivales(){
        
        if(num_rivales == 0){
            
            int posicion_rival = getRandomNumber(0,3);
            
            if(posicion_rival == 0){
                addObject(new estramonio(velocidad_rex),200, 25);
            }
            else if( posicion_rival == 1){
                addObject(new estramonio(velocidad_rex),250, 25);
            }
            else{
                addObject(new estramonio(velocidad_rex),500, 25);
            }
            
            posicion_rival++;
            posicion_rival = posicion_rival % 3;
            
            if(posicion_rival == 0){
                addObject(new megaconus(velocidad_rex),600, 80);
            }
            else if( posicion_rival == 1){
                addObject(new megaconus(velocidad_rex),700, 80);
            }
            else{
                addObject(new megaconus(velocidad_rex),8000, 80);
            }
            
            if(posicion_rival == 0){
                addObject(new rockero1(velocidad_rex),300, 90);
            }
            else if( posicion_rival == 1){
                addObject(new rockero1(velocidad_rex),380, 90);
            }
            else{
                addObject(new rockero1(velocidad_rex),720, 90);
            }
            
            if(posicion_rival == 0){
                addObject(new rockero2(velocidad_rex),480, 100);
            }
            else if( posicion_rival == 1){
                addObject(new rockero2(velocidad_rex),490, 95);
            }
            else{
                addObject(new rockero2(velocidad_rex),8000, 110);
            }
            
                       
            num_rivales = 3;
        }
   
             
        
    }
    
        
    
}


