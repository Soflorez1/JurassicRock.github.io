import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class rex here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class rex extends Actor
{
  public int speed;
  
  public rex (int v) {
     speed = v; 
  }
    
    
    /**
     * Act - do whatever the rex wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    if (Greenfoot.isKeyDown("right")){
            comer();
            if (getX() < 900)
            setLocation(getX()+ speed, getY());
    }    
        if (Greenfoot.isKeyDown("left")){
            comer();
            if (getX() > 130)
            setLocation(getX()- speed, getY());
    }    
  
}
  public void comer(){
        Actor estramonio;
        estramonio = getOneObjectAtOffset (0,0, estramonio.class);
        if (estramonio !=null) {
            World mundo;
            mundo=getWorld();
            mundo.removeObject(estramonio);
        }
    }      
    //}
   /* public void collied () {
        Actor collided = getOneIntersectingObject(estramonio.class);
        if(collided !=null) {
            getWorld().removeObject(collided);
            getWorld().removeObject(this);
            }    
            
        /*Actor estramonio = getOneIntersectingObject(estramonio.class);
        if(estramonio !=null) {
            World mundo;
            getWorld().getWorld();
            getWorld().removeObject(estramonio);
            }    */
           
        //}
     public void aumenta_velocidad(){
         speed++;
        }
    
    
 }
